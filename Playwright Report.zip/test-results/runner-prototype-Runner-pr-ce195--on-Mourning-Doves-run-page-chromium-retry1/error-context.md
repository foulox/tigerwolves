# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: runner-prototype.spec.ts >> Runner prototype — #302 >> RunnerNav appears on Mourning Doves run page
- Location: e2e/runner-prototype.spec.ts:116:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "http://localhost:3000/runner/run/mourning-doves", waiting until "load"

```

# Test source

```ts
  17  |   test.describe('My Week — /runner', () => {
  18  |     test.beforeEach(async ({ page }) => {
  19  |       await page.goto('/runner')
  20  |     })
  21  | 
  22  |     // AC2
  23  |     test('shows My Week with Mourning Doves as NEXT UP', async ({ page }) => {
  24  |       await expect(page.getByText('NEXT UP')).toBeVisible()
  25  |       await expect(page.getByText(/Mourning Doves/i).first()).toBeVisible()
  26  |     })
  27  | 
  28  |     // AC2 — Hellkatz not joined by default, so not in My Week
  29  |     test('does not show Hellkatz in My Week before joining', async ({ page }) => {
  30  |       // Hellkatz should either be absent or shown as a dashed "not joined" slot — never as a joined run
  31  |       const hellkatzJoined = page.locator('[data-testid="run-card-hellkatz"]')
  32  |       await expect(hellkatzJoined).not.toBeVisible()
  33  |     })
  34  | 
  35  |     // AC3
  36  |     test('tapping a run card expands to show workout detail', async ({ page }) => {
  37  |       // The Mourning Doves card is NEXT UP and should show detail on tap
  38  |       await page.getByText(/Mourning Doves/i).first().click()
  39  |       // "Hey Doves!" only appears in the expanded prose, not the compact subtitle
  40  |       await expect(page.getByText(/Hey Doves/i)).toBeVisible()
  41  |     })
  42  | 
  43  |     // AC4 — Mourning Doves links to /runner/run/mourning-doves
  44  |     test('expanded Mourning Doves card links to its run page', async ({ page }) => {
  45  |       await page.getByText(/Mourning Doves/i).first().click()
  46  |       const runLink = page.getByRole('link', { name: /See all Mourning Doves|Mourning Doves →/i })
  47  |       await expect(runLink).toBeVisible()
  48  |       await runLink.click()
  49  |       await expect(page).toHaveURL('/runner/run/mourning-doves')
  50  |     })
  51  | 
  52  |     // AC10 — RunnerNav visible; existing BottomNav hidden
  53  |     test('RunnerNav is visible and existing BottomNav is hidden', async ({ page }) => {
  54  |       await expect(page.getByRole('link', { name: 'My Week' })).toBeVisible()
  55  |       // The regular app nav has a Schedule tab — it should not appear on runner routes
  56  |       const scheduleLink = page.getByRole('link', { name: 'Schedule' })
  57  |       await expect(scheduleLink).not.toBeVisible()
  58  |     })
  59  | 
  60  |     // AC12
  61  |     test('page loads without horizontal scroll at 390px', async ({ page }) => {
  62  |       const overflow = await page.evaluate(() => document.body.scrollWidth > window.innerWidth)
  63  |       expect(overflow).toBe(false)
  64  |     })
  65  |   })
  66  | 
  67  |   // AC5
  68  |   test('Mourning Doves run page shows upcoming Wednesday workouts', async ({ page }) => {
  69  |     await page.goto('/runner/run/mourning-doves')
  70  |     await expect(page.getByText(/Mourning Doves/i).first()).toBeVisible()
  71  |     await expect(page.getByText('NEXT UP')).toBeVisible()
  72  |     await expect(page.getByText(/Socrates Sculpture Park/i)).toBeVisible()
  73  |     // "Wednesday, Sep 9" is exact — avoids false matches on Sep 16's "~9mi" description
  74  |     await expect(page.getByText('Wednesday, Sep 9').first()).toBeVisible()
  75  |   })
  76  | 
  77  |   test.describe('All Runs — /runner/all-runs', () => {
  78  |     test.beforeEach(async ({ page }) => {
  79  |       await page.goto('/runner/all-runs')
  80  |     })
  81  | 
  82  |     // AC6
  83  |     test('shows joined runs with joined badge and Hellkatz as available-to-join', async ({ page }) => {
  84  |       // Joined runs should be visible
  85  |       await expect(page.getByText('TigerWolves')).toBeVisible()
  86  |       await expect(page.getByText('Mourning Doves')).toBeVisible()
  87  |       // Helkatz shown as available
  88  |       await expect(page.getByText('Helkatz')).toBeVisible()
  89  |     })
  90  | 
  91  |     // AC7
  92  |     test('tapping Hellkatz opens join confirmation sheet', async ({ page }) => {
  93  |       await page.getByText('Helkatz').click()
  94  |       // Use heading role to avoid matching both the h2 and the identically-named button
  95  |       await expect(page.getByRole('heading', { name: 'Join the Helkatz Train' })).toBeVisible()
  96  |     })
  97  | 
  98  |     // AC8
  99  |     test('confirming join adds Hellkatz to My Week via localStorage', async ({ page }) => {
  100 |       await page.getByText('Helkatz').click()
  101 |       await page.getByRole('button', { name: 'Join the Helkatz Train' }).click()
  102 |       // Navigate to My Week — localStorage persists within same test context
  103 |       await page.goto('/runner')
  104 |       // Helkatz should now appear in My Week
  105 |       await expect(page.getByText('Helkatz')).toBeVisible()
  106 |     })
  107 | 
  108 |     // AC9 — all runs tappable (TigerWolves links to /, Mourning Doves to its run page)
  109 |     test('TigerWolves card links to the main schedule page', async ({ page }) => {
  110 |       const twLink = page.getByRole('link', { name: /TigerWolves/i })
  111 |       await expect(twLink).toBeVisible()
  112 |     })
  113 |   })
  114 | 
  115 |   // AC10 — RunnerNav appears on /runner/run/mourning-doves too
  116 |   test('RunnerNav appears on Mourning Doves run page', async ({ page }) => {
> 117 |     await page.goto('/runner/run/mourning-doves')
      |                ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  118 |     await expect(page.getByRole('link', { name: 'My Week' })).toBeVisible()
  119 |   })
  120 | 
  121 |   // AC12 — also check All Runs at 390px
  122 |   test('/runner/all-runs loads without horizontal scroll at 390px', async ({ page }) => {
  123 |     await page.goto('/runner/all-runs')
  124 |     const overflow = await page.evaluate(() => document.body.scrollWidth > window.innerWidth)
  125 |     expect(overflow).toBe(false)
  126 |   })
  127 | })
  128 | 
```