# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin.spec.ts >> Regroup flow merges the two reserved fixture workouts into a new family
- Location: e2e/admin.spec.ts:21:5

# Error details

```
Test timeout of 90000ms exceeded.
```

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "http://localhost:3000/admin", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test('Admin page loads with Regroup Workouts heading', async ({ page }) => {
  4  |   test.setTimeout(90000)
  5  |   await page.goto('/admin')
  6  |   await page.waitForLoadState('load')
  7  |   await expect(page.getByRole('heading', { name: /regroup workouts/i })).toBeVisible()
  8  | })
  9  | 
  10 | test('Configure button is visible in viewport without scrolling', async ({ page }) => {
  11 |   test.setTimeout(90000)
  12 |   await page.goto('/admin')
  13 |   await page.waitForLoadState('load')
  14 | 
  15 |   // The fixed footer means Configure is always in the viewport — no scrolling needed
  16 |   const configureBtn = page.getByRole('button', { name: /configure/i })
  17 |   await expect(configureBtn).toBeVisible()
  18 |   await expect(configureBtn).toBeInViewport()
  19 | })
  20 | 
  21 | test('Regroup flow merges the two reserved fixture workouts into a new family', async ({ page }) => {
  22 |   test.setTimeout(90000)
> 23 |   await page.goto('/admin')
     |              ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  24 |   await page.waitForLoadState('load')
  25 | 
  26 |   await page.locator('[data-testid="regroup-option-McCarren Loop Repeats||Short loop, 6x800m"]').click()
  27 |   await page.locator('[data-testid="regroup-option-McCarren Loop Repeats||Long loop, 4x1200m"]').click()
  28 | 
  29 |   const configureBtn = page.getByRole('button', { name: /configure/i })
  30 |   await expect(configureBtn).toBeEnabled()
  31 |   await configureBtn.click()
  32 | 
  33 |   await page.locator('[data-testid="regroup-family-name"]').fill('Greenpoint Loop Ladder')
  34 |   await page.locator('[data-testid="regroup-variation-input-0"]').fill('Short loop, 6x800m')
  35 |   await page.locator('[data-testid="regroup-variation-input-1"]').fill('Long loop, 4x1200m')
  36 | 
  37 |   await page.locator('[data-testid="regroup-save"]').click()
  38 | 
  39 |   // regroupFamily redirects to /library on success — arriving there is itself
  40 |   // evidence the server action didn't throw.
  41 |   await page.waitForURL(/\/library/)
  42 |   await page.waitForLoadState('load')
  43 | 
  44 |   await expect(page.getByText('Greenpoint Loop Ladder').first()).toBeVisible()
  45 |   await expect(page.getByText('McCarren Loop Repeats')).toHaveCount(0)
  46 | })
  47 | 
```