# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library.spec.ts >> Flag round trip: leader reviews a reported issue and saves a fix, clearing the flag (#277 — variant_id write path)
- Location: e2e/library.spec.ts:70:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "http://localhost:3000/library", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test('Library page loads with all 8 fixture workout names', async ({ page }) => {
  4  |   await page.goto('/library')
  5  |   await page.waitForLoadState('load')
  6  | 
  7  |   const countEl = page.locator('p').filter({ hasText: /workouts · oldest first/ })
  8  |   await expect(countEl).toHaveText('8 workouts · oldest first')
  9  | 
  10 |   await expect(page.getByText('Easy Recovery Run')).toBeVisible()
  11 |   await expect(page.getByText('Long Run — Progressive')).toBeVisible()
  12 |   await expect(page.getByText('Yasso 800s')).toBeVisible()
  13 |   await expect(page.getByText('Fort Greene Hills')).toBeVisible()
  14 |   await expect(page.getByText('Prospect Park Tempo')).toBeVisible()
  15 |   await expect(page.getByText('Track Ladder 400-800-1200')).toBeVisible()
  16 |   // The two McCarren Loop Repeats rows are reserved for admin.spec.ts's regroup
  17 |   // test and asserted there — not here. admin.spec.ts renames them in place,
  18 |   // and since these specs share one seeded suite run (not reset per test),
  19 |   // asserting their original name here would be order-dependent.
  20 | })
  21 | 
  22 | test('Library category filter narrows to exactly the 6 Quality-category rows', async ({ page }) => {
  23 |   await page.goto('/library')
  24 |   await page.waitForLoadState('load')
  25 | 
  26 |   const countEl = page.locator('p').filter({ hasText: /workouts · oldest first/ })
  27 |   await expect(countEl).toHaveText('8 workouts · oldest first')
  28 | 
  29 |   await page.getByRole('button', { name: 'Quality', exact: true }).click()
  30 |   await expect(countEl).toHaveText('6 workouts · oldest first')
  31 | 
  32 |   // Easy/Long baseline workouts must drop out of the filtered view
  33 |   await expect(page.getByText('Easy Recovery Run')).toHaveCount(0)
  34 |   await expect(page.getByText('Long Run — Progressive')).toHaveCount(0)
  35 |   await expect(page.getByText('Fort Greene Hills')).toBeVisible()
  36 | })
  37 | 
  38 | // Appended below the count-assertion tests above (not interspersed) — these two
  39 | // mutate fixture state (adds a variant, clears a flag), so they must run after
  40 | // anything in this file/suite that counts fixture rows by name.
  41 | 
  42 | test('Add variation: a new variation shows up immediately in Library AND on Plan (#277 — closes the addVariation split-brain gap)', async ({ page }) => {
  43 |   await page.goto('/library')
  44 |   await page.waitForLoadState('load')
  45 | 
  46 |   const card = page.locator('.bg-white.rounded-2xl', { hasText: 'Prospect Park Tempo' })
  47 |   await card.getByText('+ Add variation').click()
  48 | 
  49 |   await page.waitForLoadState('load')
  50 |   await expect(page.getByRole('heading', { name: 'Add Variation' })).toBeVisible()
  51 |   await page.getByPlaceholder('e.g. 3×2mi@HMP, r3min').fill('12min tempo instead of 20min')
  52 |   await page.getByRole('button', { name: 'Save Variation' }).click()
  53 | 
  54 |   await page.waitForURL(/\/library/)
  55 |   await page.waitForLoadState('load')
  56 |   const familyCard = page.locator('.bg-white.rounded-2xl', { hasText: 'Prospect Park Tempo' })
  57 |   await expect(familyCard.getByText('2 versions')).toBeVisible()
  58 | 
  59 |   // Plan's browse picker searches the full library regardless of the scheduled
  60 |   // week's workout type — proves the new variant is visible there too, not just
  61 |   // in the Library (the other half of the addWorkout/addVariation split-brain).
  62 |   await page.goto('/plan?week=0')
  63 |   await page.waitForLoadState('load')
  64 |   const browseTab = page.getByRole('button', { name: 'Change workout', exact: true })
  65 |   if (await browseTab.isVisible()) await browseTab.click()
  66 |   await page.locator('input[type="search"]').fill('Prospect Park Tempo')
  67 |   await expect(page.getByText('12min tempo instead of 20min')).toBeVisible()
  68 | })
  69 | 
  70 | test('Flag round trip: leader reviews a reported issue and saves a fix, clearing the flag (#277 — variant_id write path)', async ({ page }) => {
> 71 |   await page.goto('/library')
     |              ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  72 |   await page.waitForLoadState('load')
  73 | 
  74 |   await page.getByRole('button', { name: 'Issue reported — view details' }).click()
  75 |   await expect(page.getByRole('heading', { name: 'Review & fix' })).toBeVisible()
  76 |   await expect(page.getByText("We've actually been running 8 reps lately")).toBeVisible()
  77 | 
  78 |   await page.getByRole('button', { name: 'Save fix & clear flag' }).click()
  79 |   // The sheet closes client-side as soon as the action resolves, but the
  80 |   // server's unstable_cache tag invalidation (updateTag) can trail slightly
  81 |   // behind that in local dev — wait for the sheet to actually close before
  82 |   // reloading, rather than racing a fixed reload against an in-flight action.
  83 |   await expect(page.getByRole('heading', { name: 'Review & fix' })).not.toBeVisible()
  84 | 
  85 |   await page.reload()
  86 |   await page.waitForLoadState('load')
  87 |   await expect(page.getByRole('button', { name: 'Issue reported — view details' })).toHaveCount(0)
  88 | })
  89 | 
```