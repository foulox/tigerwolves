# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: races.spec.ts >> Opening the reported issue on the flagged race shows its flag note — leader gets the Review & fix sheet
- Location: e2e/races.spec.ts:15:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "http://localhost:3000/races", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test('Races page shows both fixture races with correct verified/flagged state', async ({ page }) => {
  4  |   await page.goto('/races')
  5  |   await page.waitForLoadState('load')
  6  | 
  7  |   const verifiedCard = page.locator('[data-testid="race-card-Brooklyn Half Marathon"]')
  8  |   await expect(verifiedCard.getByText('Verified', { exact: true })).toBeVisible()
  9  | 
  10 |   const flaggedCard = page.locator('[data-testid="race-card-Prospect Park 5K Series #3"]')
  11 |   await expect(flaggedCard.getByText('Unverified')).toBeVisible()
  12 |   await expect(flaggedCard.getByRole('button', { name: 'Issue reported' })).toBeVisible()
  13 | })
  14 | 
  15 | test('Opening the reported issue on the flagged race shows its flag note — leader gets the Review & fix sheet', async ({ page }) => {
> 16 |   await page.goto('/races')
     |              ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  17 |   await page.waitForLoadState('load')
  18 | 
  19 |   const flaggedCard = page.locator('[data-testid="race-card-Prospect Park 5K Series #3"]')
  20 |   await flaggedCard.getByRole('button', { name: 'Issue reported' }).click()
  21 | 
  22 |   // openIssue() routes leaders to the editable 'fix' sheet ("Review & fix"),
  23 |   // not the read-only 'view' sheet ("Reported issue") non-leaders would see —
  24 |   // this suite always runs as a signed-in leader.
  25 |   await expect(page.getByRole('heading', { name: 'Review & fix' })).toBeVisible()
  26 |   await expect(page.getByText("Date TBD — organizer hasn't confirmed")).toBeVisible()
  27 | })
  28 | 
```