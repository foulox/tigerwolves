# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: all-runs.spec.ts >> header is standard Header.tsx — no Join NBR, no NORTH BROOKLYN RUNNERS eyebrow (AC10)
- Location: e2e/all-runs.spec.ts:118:5

# Error details

```
Test timeout of 30000ms exceeded.
```