# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: all-runs.spec.ts >> page renders without horizontal overflow at 390px (AC9)
- Location: e2e/all-runs.spec.ts:110:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "http://localhost:3000/all-runs", waiting until "load"

```

# Test source

```ts
  12  |   await expect(tab).toContainText('All Runs')
  13  | })
  14  | 
  15  | test('loads without auth cookies — no redirect to sign-in (AC2)', async ({ browser }) => {
  16  |   const context = await browser.newContext({ storageState: { cookies: [], origins: [] } })
  17  |   const page = await context.newPage()
  18  |   await page.goto('/all-runs')
  19  |   await page.waitForLoadState('load')
  20  |   expect(page.url()).toContain('/all-runs')
  21  |   expect(page.url()).not.toContain('/sign-in')
  22  |   await context.close()
  23  | })
  24  | 
  25  | test('run rows are visible with name, time, and category pill (AC3)', async ({ page }) => {
  26  |   await page.goto('/all-runs')
  27  |   await page.waitForLoadState('load')
  28  |   const rows = page.locator('[data-testid="run-row"]')
  29  |   expect(await rows.count()).toBeGreaterThan(0)
  30  |   await expect(page.locator('[data-testid="run-name"]').first()).toBeVisible()
  31  |   await expect(page.locator('[data-testid="run-category-pill"]').first()).toBeVisible()
  32  | })
  33  | 
  34  | test('Morning filter hides PM runs; Evening filter hides AM runs; Weekend shows only Sat/Sun (AC4)', async ({ page }) => {
  35  |   await page.goto('/all-runs')
  36  |   await page.waitForLoadState('load')
  37  | 
  38  |   // Morning: all visible run times should end in "am"
  39  |   await page.locator('[data-testid="time-filter-am"]').click()
  40  |   const morningRows = page.locator('[data-testid="run-row"]')
  41  |   const morningCount = await morningRows.count()
  42  |   expect(morningCount).toBeGreaterThan(0)
  43  |   for (let i = 0; i < morningCount; i++) {
  44  |     const timeEl = morningRows.nth(i).locator('span').first()
  45  |     await expect(timeEl).not.toContainText('pm')
  46  |   }
  47  | 
  48  |   // Evening: all visible run times should end in "pm"
  49  |   await page.locator('[data-testid="time-filter-pm"]').click()
  50  |   const eveningRows = page.locator('[data-testid="run-row"]')
  51  |   const eveningCount = await eveningRows.count()
  52  |   expect(eveningCount).toBeGreaterThan(0)
  53  |   for (let i = 0; i < eveningCount; i++) {
  54  |     const timeEl = eveningRows.nth(i).locator('span').first()
  55  |     await expect(timeEl).not.toContainText('am')
  56  |   }
  57  | 
  58  |   // Weekend: only Sat and Sun day blocks should be present
  59  |   await page.locator('[data-testid="time-filter-wknd"]').click()
  60  |   await expect(page.locator('[data-testid="day-block-sat"]')).toBeVisible()
  61  |   await expect(page.locator('[data-testid="day-block-sun"]')).toBeVisible()
  62  |   const allBlocks = page.locator('[data-testid^="day-block-"]')
  63  |   await expect(allBlocks).toHaveCount(2)
  64  | })
  65  | 
  66  | test('Workouts category chip shows only Workouts-labelled runs (AC5)', async ({ page }) => {
  67  |   await page.goto('/all-runs')
  68  |   await page.waitForLoadState('load')
  69  |   await page.locator('[data-testid="category-chip-workouts"]').click()
  70  |   const pills = page.locator('[data-testid="run-category-pill"]')
  71  |   const count = await pills.count()
  72  |   expect(count).toBeGreaterThan(0)
  73  |   for (let i = 0; i < count; i++) {
  74  |     await expect(pills.nth(i)).toHaveText('Workouts')
  75  |   }
  76  | })
  77  | 
  78  | test('food-run filter empties at least one lead day; later non-matching days are absent (AC6)', async ({ page }) => {
  79  |   await page.goto('/all-runs')
  80  |   await page.waitForLoadState('load')
  81  | 
  82  |   // Food Runs exist only on Friday — at least one of Today/Tomorrow is always a non-Friday
  83  |   await page.locator(ALWAYS_EMPTY_LEAD_DAY_CATEGORY).click()
  84  | 
  85  |   // At least one lead day must show the empty-state panel
  86  |   const emptyStates = page.locator('[data-testid="empty-day-state"]')
  87  |   expect(await emptyStates.count()).toBeGreaterThan(0)
  88  | 
  89  |   // No non-Fri day block should contain run rows (Food Runs are Fridays only)
  90  |   const nonFriBlocks = ['mon', 'tue', 'wed', 'thu', 'sat', 'sun']
  91  |   for (const day of nonFriBlocks) {
  92  |     const block = page.locator(`[data-testid="day-block-${day}"]`)
  93  |     // Non-lead days with no runs should be absent from the DOM entirely
  94  |     const count = await block.count()
  95  |     if (count > 0) {
  96  |       await expect(block.locator('[data-testid="run-row"]')).toHaveCount(0)
  97  |     }
  98  |   }
  99  | })
  100 | 
  101 | test('"Lead a run that isn\'t here?" CTA is visible; Add your run opens feedback drawer pre-set to run-leader (AC7)', async ({ page }) => {
  102 |   await page.goto('/all-runs')
  103 |   await page.waitForLoadState('load')
  104 |   await expect(page.locator('[data-testid="leader-cta"]')).toBeVisible()
  105 |   await page.locator('[data-testid="add-your-run-btn"]').click()
  106 |   await expect(page.getByText('Send Feedback')).toBeVisible()
  107 |   await expect(page.getByText('Run leader feedback')).toBeVisible()
  108 | })
  109 | 
  110 | test('page renders without horizontal overflow at 390px (AC9)', async ({ page }) => {
  111 |   await page.setViewportSize({ width: 390, height: 844 })
> 112 |   await page.goto('/all-runs')
      |              ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  113 |   await page.waitForLoadState('load')
  114 |   const overflow = await page.evaluate(() => document.body.scrollWidth > document.body.clientWidth)
  115 |   expect(overflow).toBe(false)
  116 | })
  117 | 
  118 | test('header is standard Header.tsx — no Join NBR, no NORTH BROOKLYN RUNNERS eyebrow (AC10)', async ({ browser }) => {
  119 |   const context = await browser.newContext({ storageState: { cookies: [], origins: [] } })
  120 |   const page = await context.newPage()
  121 |   await page.goto('/all-runs')
  122 |   await page.waitForLoadState('load')
  123 |   await expect(page.getByText('Join NBR', { exact: false })).toHaveCount(0)
  124 |   await expect(page.getByText('NORTH BROOKLYN RUNNERS', { exact: false })).toHaveCount(0)
  125 |   // Standard sign-in link (not a "Log in" text link) should be present for logged-out users
  126 |   await expect(page.locator('a[href*="sign-in"]')).toBeVisible()
  127 |   await context.close()
  128 | })
  129 | 
```