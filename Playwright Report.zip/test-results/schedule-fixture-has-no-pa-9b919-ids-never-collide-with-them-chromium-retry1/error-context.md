# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: schedule.spec.ts >> fixture has no past history — past-card testids never appear, and upcoming testids never collide with them
- Location: e2e/schedule.spec.ts:73:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "http://localhost:3000/", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test('Schedule page shows the three seeded upcoming Tuesdays', async ({ page }) => {
  4  |   await page.goto('/')
  5  |   await page.waitForLoadState('load')
  6  | 
  7  |   await expect(page.locator('[data-testid="schedule-card-0"]')).toContainText('Yasso 800s')
  8  |   await expect(page.locator('[data-testid="schedule-card-0"]')).toContainText('Led by Dana Kim')
  9  | 
  10 |   await expect(page.locator('[data-testid="schedule-card-1"]')).toContainText('Fort Greene Hills')
  11 |   await expect(page.locator('[data-testid="schedule-card-1"]')).toContainText('Led by Marcus Ade')
  12 | 
  13 |   await expect(page.locator('[data-testid="schedule-card-2"]')).toContainText('Not planned yet')
  14 |   await expect(page.locator('[data-testid="schedule-card-2"]')).toContainText('Led by Priya Shah')
  15 | })
  16 | 
  17 | test('"Plan week →" button appears on all three cards for signed-in leaders', async ({ page }) => {
  18 |   await page.goto('/')
  19 |   await page.waitForLoadState('load')
  20 | 
  21 |   const cards = page.locator('[data-testid^="schedule-card-"]')
  22 |   await expect(cards).toHaveCount(3)
  23 | 
  24 |   for (let i = 0; i < 3; i++) {
  25 |     const btn = page.locator(`[data-testid="plan-week-${i}"]`)
  26 |     await expect(btn).toBeVisible()
  27 |     await expect(btn).toContainText('Plan week')
  28 |   }
  29 | })
  30 | 
  31 | test('"Plan week →" navigates to /plan?week=N', async ({ page }) => {
  32 |   await page.goto('/')
  33 |   await page.waitForLoadState('load')
  34 | 
  35 |   await page.locator('[data-testid="plan-week-0"]').click()
  36 |   await page.waitForURL(/\/plan\?week=0/)
  37 |   expect(page.url()).toContain('/plan?week=0')
  38 | })
  39 | 
  40 | test('card with planned workout expands to show fixture instructions on tap', async ({ page }) => {
  41 |   await page.goto('/')
  42 |   await page.waitForLoadState('load')
  43 | 
  44 |   await page.locator('[data-testid="schedule-card-0"]').click()
  45 |   const detail = page.locator('[data-testid="schedule-detail-0"]')
  46 |   await expect(detail).toBeVisible()
  47 |   await expect(detail).toContainText('10x800m @ 5K effort')
  48 | })
  49 | 
  50 | test('expanded card collapses on second tap', async ({ page }) => {
  51 |   await page.goto('/')
  52 |   await page.waitForLoadState('load')
  53 | 
  54 |   const card = page.locator('[data-testid="schedule-card-0"]')
  55 |   const detail = page.locator('[data-testid="schedule-detail-0"]')
  56 | 
  57 |   await card.click()
  58 |   await expect(detail).toBeVisible()
  59 | 
  60 |   await card.click()
  61 |   await expect(detail).not.toBeVisible()
  62 | })
  63 | 
  64 | test('unplanned card has no expand affordance', async ({ page }) => {
  65 |   await page.goto('/')
  66 |   await page.waitForLoadState('load')
  67 | 
  68 |   // Card 2 has no workout — clicking it must not reveal a detail panel
  69 |   await page.locator('[data-testid="schedule-card-2"]').click()
  70 |   await expect(page.locator('[data-testid="schedule-detail-2"]')).toHaveCount(0)
  71 | })
  72 | 
  73 | test('fixture has no past history — past-card testids never appear, and upcoming testids never collide with them', async ({ page }) => {
> 74 |   await page.goto('/')
     |              ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  75 |   await page.waitForLoadState('load')
  76 | 
  77 |   await expect(page.locator('[data-testid^="past-card-"]')).toHaveCount(0)
  78 | 
  79 |   const scheduleCards = page.locator('[data-testid^="schedule-card-"]')
  80 |   const count = await scheduleCards.count()
  81 |   for (let i = 0; i < count; i++) {
  82 |     const testId = await scheduleCards.nth(i).getAttribute('data-testid')
  83 |     expect(testId).not.toContain('past')
  84 |   }
  85 | })
  86 | 
```