# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: all-runs.spec.ts >> loads without auth cookies — no redirect to sign-in (AC2)
- Location: e2e/all-runs.spec.ts:15:5

# Error details

```
Test timeout of 30000ms exceeded.
```