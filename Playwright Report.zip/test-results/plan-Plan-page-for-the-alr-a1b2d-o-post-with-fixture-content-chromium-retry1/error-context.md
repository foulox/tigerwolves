# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: plan.spec.ts >> Plan page for the already-planned week shows the Heylo post with fixture content
- Location: e2e/plan.spec.ts:3:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "http://localhost:3000/plan?week=0", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test('Plan page for the already-planned week shows the Heylo post with fixture content', async ({ page }) => {
> 4  |   await page.goto('/plan?week=0')
     |              ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  5  |   await page.waitForLoadState('load')
  6  | 
  7  |   await expect(page.getByRole('button', { name: 'Post draft', exact: true })).toBeVisible()
  8  |   const post = page.locator('pre').first()
  9  |   await expect(post).toContainText('Yasso 800s')
  10 |   await expect(post).toContainText('10x800m @ 5K effort')
  11 |   await expect(page.getByRole('button', { name: /copy to clipboard/i })).toBeVisible()
  12 | })
  13 | 
  14 | test('Plan page for the unplanned week lets a leader pick a fixture workout and generates its Heylo post', async ({ page }) => {
  15 |   await page.goto('/plan?week=2')
  16 |   await page.waitForLoadState('load')
  17 | 
  18 |   // No workout planned yet for this week — the picker shows directly, no tabs.
  19 |   await expect(page.getByRole('button', { name: 'Post draft', exact: true })).toHaveCount(0)
  20 | 
  21 |   await page.locator('button').filter({ hasText: 'Fort Greene Hills' }).first().click()
  22 | 
  23 |   const post = page.locator('pre').first()
  24 |   await expect(post).toContainText('Fort Greene Hills')
  25 |   await expect(post).toContainText('8x90sec hill repeats')
  26 | })
  27 | 
  28 | test('verification checkbox is required before copy', async ({ page }) => {
  29 |   await page.goto('/plan?week=0')
  30 |   await page.waitForLoadState('load')
  31 | 
  32 |   // Planned week shows Post draft tab with copy button — must be disabled before checkbox
  33 |   const copyBtn = page.getByRole('button', { name: /copy to clipboard/i })
  34 |   await expect(copyBtn).toBeDisabled()
  35 | 
  36 |   const checkbox = page.getByRole('checkbox')
  37 |   await checkbox.check()
  38 |   await expect(copyBtn).toBeEnabled()
  39 | })
  40 | 
  41 | test('TigerWolves post contains correct branding', async ({ page }) => {
  42 |   await page.goto('/plan?week=0')
  43 |   await page.waitForLoadState('load')
  44 | 
  45 |   const post = await page.locator('pre').first().textContent()
  46 |   expect(post).toContain('TigerWolves')
  47 |   expect(post).not.toContain('undefined')
  48 |   expect(post).not.toContain('null')
  49 | })
  50 | 
  51 | test('Plan page tab switch: Post draft is default, Change workout reveals the picker, and switching back preserves the post', async ({ page }) => {
  52 |   await page.goto('/plan?week=0')
  53 |   await page.waitForLoadState('load')
  54 | 
  55 |   const postTab = page.getByRole('button', { name: 'Post draft', exact: true })
  56 |   const browseTab = page.getByRole('button', { name: 'Change workout', exact: true })
  57 | 
  58 |   // Default view: Post draft tab active, showing the post + Copy button, no search bar
  59 |   await expect(page.getByRole('button', { name: /copy to clipboard/i })).toBeVisible()
  60 |   await expect(page.locator('input[type="search"]')).not.toBeVisible()
  61 | 
  62 |   // Switching to Change workout reveals the search bar and browse list, hides the post
  63 |   await browseTab.click()
  64 |   await expect(page.locator('input[type="search"]')).toBeVisible()
  65 |   await expect(page.getByRole('button', { name: /copy to clipboard/i })).not.toBeVisible()
  66 | 
  67 |   // Switching back to Post draft restores the post view, still the fixture's workout
  68 |   await postTab.click()
  69 |   await expect(page.getByRole('button', { name: /copy to clipboard/i })).toBeVisible()
  70 |   await expect(page.locator('input[type="search"]')).not.toBeVisible()
  71 |   await expect(page.locator('pre').first()).toContainText('Yasso 800s')
  72 | })
  73 | 
```