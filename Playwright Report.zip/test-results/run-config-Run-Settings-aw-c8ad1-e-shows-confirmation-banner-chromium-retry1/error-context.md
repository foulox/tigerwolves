# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: run-config.spec.ts >> Run Settings >> away period save shows confirmation banner
- Location: e2e/run-config.spec.ts:46:7

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
Call log:
  - navigating to "http://localhost:3000/run-config", waiting until "load"

```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test'
  2  | 
  3  | test.describe('Run Settings', () => {
  4  |   // storageState defaults to e2e/.auth/user.json via playwright.config.ts project config
  5  |   // The seeded test leader has the 'leader' role set in Clerk publicMetadata.
  6  | 
  7  |   test('Run Settings link appears in Clerk UserButton menu', async ({ page }) => {
  8  |     await page.goto('/')
  9  |     await page.waitForLoadState('load')
  10 |     // Run Settings is a Clerk UserButton.Link, not a hamburger menu link.
  11 |     // The UserButton renders as an avatar button; click it to open the dropdown.
  12 |     // Clerk's rendered class is .cl-userButtonTrigger; data-testid fallbacks are also tried.
  13 |     // NOTE: exact selector may need tuning against a live Preview URL — Clerk's DOM
  14 |     // class names are stable across minor versions but verify if this fails after a
  15 |     // Clerk SDK upgrade.
  16 |     const trigger =
  17 |       page.locator('[data-testid="user-button-trigger"]').first().or(
  18 |         page.locator('.cl-userButtonTrigger').first()
  19 |       )
  20 |     await trigger.click()
  21 |     await expect(page.getByRole('menuitem', { name: /run settings/i })
  22 |       .or(page.getByText(/run settings/i))).toBeVisible()
  23 |   })
  24 | 
  25 |   test('post template saves and persists', async ({ page }) => {
  26 |     await page.goto('/run-config')
  27 |     await page.waitForLoadState('load')
  28 | 
  29 |     const input = page.getByLabel(/meeting location/i)
  30 |     const original = await input.inputValue()
  31 |     await input.fill('Test Location Updated')
  32 |     await page.getByRole('button', { name: /save changes/i }).click()
  33 |     await expect(page.getByRole('button', { name: /saved/i })).toBeVisible()
  34 | 
  35 |     // Reload and verify persistence
  36 |     await page.reload()
  37 |     await page.waitForLoadState('load')
  38 |     await expect(page.getByLabel(/meeting location/i)).toHaveValue('Test Location Updated')
  39 | 
  40 |     // Restore original value
  41 |     await input.fill(original)
  42 |     await page.getByRole('button', { name: /save changes/i }).click()
  43 |     await expect(page.getByRole('button', { name: /saved/i })).toBeVisible()
  44 |   })
  45 | 
  46 |   test('away period save shows confirmation banner', async ({ page }) => {
> 47 |     await page.goto('/run-config')
     |                ^ Error: page.goto: net::ERR_ABORTED; maybe frame was detached?
  48 |     await page.waitForLoadState('load')
  49 | 
  50 |     // Switch to the Roster tab
  51 |     await page.getByRole('button', { name: 'Roster' }).click()
  52 | 
  53 |     // Open the away panel for the first leader in the list
  54 |     await page.getByRole('button', { name: /away/i }).first().click()
  55 | 
  56 |     await page.getByLabel('From').fill('2099-01-01')
  57 |     await page.getByLabel('To').fill('2099-01-07')
  58 |     await page.getByRole('button', { name: /save away period/i }).click()
  59 | 
  60 |     await expect(page.getByText(/away period saved/i)).toBeVisible()
  61 |   })
  62 | })
  63 | 
```